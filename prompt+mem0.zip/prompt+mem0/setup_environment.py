#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
环境设置脚本 - 自动检测和安装必要的依赖
"""

import subprocess
import sys
import os

def check_and_install_package(package_name, import_name=None):
    """检查并安装包"""
    if import_name is None:
        import_name = package_name
    
    try:
        __import__(import_name)
        print(f"✅ {package_name} 已安装")
        return True
    except ImportError:
        print(f"❌ {package_name} 未安装，正在安装...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
            print(f"✅ {package_name} 安装成功")
            return True
        except subprocess.CalledProcessError:
            print(f"❌ {package_name} 安装失败")
            return False

def main():
    print("🔧 检查并安装必要的依赖包...")
    print("=" * 50)
    
    # 检查必要的包
    packages = [
        ("openai", "openai"),
        ("mem0ai", "mem0")
    ]
    
    all_installed = True
    for package_name, import_name in packages:
        if not check_and_install_package(package_name, import_name):
            all_installed = False
    
    print("=" * 50)
    if all_installed:
        print("🎉 所有依赖包已准备就绪！")
        print("现在可以运行 companion_system_demo.py")
    else:
        print("⚠️  部分依赖包安装失败，请手动安装：")
        print("pip install openai mem0ai")
    
    return all_installed

if __name__ == "__main__":
    main()
