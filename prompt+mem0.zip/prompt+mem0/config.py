#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
配置文件 - 管理API密钥和其他设置
"""

# GPT-3.5 API配置
GPT_API_KEY = "sk-wxCNdypZO6TDKRFBex8PexjgwAlRVE1UrIrwkrzE3oa3yGtA"
GPT_BASE_URL = "https://api.poixe.com/v1"

# mem0 OpenAI API配置
# 注意：mem0需要OpenAI API密钥来进行文本向量化
# 如果您有专门的mem0 OpenAI API密钥，请在这里替换
MEM0_OPENAI_API_KEY = "m0-vqYqiCWyJDqS1N2sEZznR7qdkmLWOc4OYDAKnJGt"
# 系统配置
MAX_SHORT_TERM_MEMORY = 10  # 短期记忆最大轮数
CONTEXT_WINDOW_SIZE = 5  # 上下文滑动窗口大小
EMOTION_CONFIDENCE_THRESHOLD = 0.3  # 情绪识别置信度阈值

# 模型配置
GPT_MODEL = "gpt-3.5-turbo:free"
TEMPERATURE = 0.8
MAX_TOKENS = 500
