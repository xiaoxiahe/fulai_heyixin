#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试导入和基本功能
"""

import os

# 测试导入
try:
    from openai import OpenAI
    print("OK OpenAI 导入成功")
except ImportError as e:
    print(f"ERROR OpenAI 导入失败: {e}")

try:
    import mem0
    from mem0 import Memory
    print("OK mem0 导入成功")
    MEM0_AVAILABLE = True
except ImportError as e:
    print(f"WARNING mem0 导入失败: {e}")
    MEM0_AVAILABLE = False

# 测试初始化
if MEM0_AVAILABLE:
    try:
        # 设置 API key
        os.environ["OPENAI_API_KEY"] = "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"
        memory = Memory()
        print("OK mem0 Memory 初始化成功")
    except Exception as e:
        print(f"ERROR mem0 Memory 初始化失败: {e}")

# 测试 OpenAI 客户端
try:
    client = OpenAI(
        api_key="sk-wxCNdypZO6TDKRFBex8PexjgwAlRVE1UrIrwkrzE3oa3yGtA",
        base_url="https://api.poixe.com/v1"
    )
    print("OK OpenAI 客户端初始化成功")
except Exception as e:
    print(f"ERROR OpenAI 客户端初始化失败: {e}")

print("=" * 50)
print("测试完成！")
