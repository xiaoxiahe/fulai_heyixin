# 情绪识别陪伴系统

基于长期记忆的情绪识别陪伴系统，整合对话、情绪识别、短期记忆和长期记忆功能。

## 功能特点

- 🤖 **智能对话**: 使用GPT-3.5进行自然对话
- 😊 **情绪识别**: 自动识别用户情绪状态（中性、伤心、生气、高兴）
- 🧠 **短期记忆**: 维护最近10轮对话的上下文
- 💾 **长期记忆**: 使用mem0系统存储和检索历史对话
- 🔍 **智能检索**: 在用户情绪低落时自动搜索相关历史记忆

## 安装依赖

```bash
pip install openai mem0ai
```

或者运行环境设置脚本：

```bash
python setup_environment.py
```

## 配置API密钥

编辑 `config.py` 文件，设置您的API密钥：

```python
# GPT-3.5 API配置
GPT_API_KEY = "your-gpt-api-key-here"

# mem0 OpenAI API配置
MEM0_OPENAI_API_KEY = "your-mem0-openai-api-key-here"
```

## 使用方法

### 1. 基本使用

```bash
python companion_system_demo.py
```

### 2. 测试导入

```bash
python test_import.py
```

### 3. 自定义配置

```python
from companion_system_demo import EmotionCompanionSystem

# 使用自定义API密钥
companion = EmotionCompanionSystem(
    gpt_api_key="your-gpt-key",
    mem0_api_key="your-mem0-key"
)

# 处理用户输入
result = companion.process_user_input("我今天心情不好")
print(result['model_response'])
```

## 交互命令

在交互式会话中，您可以使用以下命令：

- `quit` - 退出程序
- `summary` - 查看记忆摘要
- `clear` - 清空短期记忆

## 系统架构

1. **情绪识别模块**: 使用GPT-3.5分析用户输入的情绪
2. **短期记忆**: 维护最近对话的上下文窗口
3. **长期记忆**: 使用mem0存储所有对话历史
4. **智能检索**: 在负面情绪时搜索相关历史记忆
5. **响应生成**: 结合情绪分析和历史记忆生成个性化回应

## 注意事项

- 确保API密钥有效且有足够的配额
- mem0需要OpenAI API密钥来进行文本向量化
- 系统会自动处理API调用失败的情况
- 长期记忆数据会持久化存储

## 文件说明

- `companion_system_demo.py` - 主程序文件
- `config.py` - 配置文件
- `setup_environment.py` - 环境设置脚本
- `test_import.py` - 测试导入脚本
