#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基于长期记忆的情绪识别陪伴系统
整合对话、情绪识别、短期记忆和长期记忆功能
"""

import os
import json
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
import uuid

# 导入配置
try:
    from config import GPT_API_KEY, GPT_BASE_URL, MEM0_OPENAI_API_KEY, MAX_SHORT_TERM_MEMORY, CONTEXT_WINDOW_SIZE, GPT_MODEL, TEMPERATURE, MAX_TOKENS
except ImportError:
    # 如果配置文件不存在，使用默认值
    GPT_API_KEY = "sk-wxCNdypZO6TDKRFBex8PexjgwAlRVE1UrIrwkrzE3oa3yGtA"
    GPT_BASE_URL = "https://api.poixe.com/v1"
    MEM0_OPENAI_API_KEY = "m0-ELF6iN4xDymtZ099Dgpaokc7EiPpXr2MYTVlNxyc"
    MAX_SHORT_TERM_MEMORY = 10
    CONTEXT_WINDOW_SIZE = 5
    GPT_MODEL = "gpt-3.5-turbo:free"
    TEMPERATURE = 0.8
    MAX_TOKENS = 500

# 导入必要的库
try:
    from openai import OpenAI
    from mem0 import MemoryClient
except ImportError as e:
    print(f"请安装必要的库: pip install openai mem0ai")
    raise e

@dataclass
class ConversationTurn:
    """对话轮次数据结构"""
    user_input: str
    model_response: str
    emotion: str
    emotion_reason: str
    timestamp: datetime
    turn_id: str

class EmotionCompanionSystem:
    """情绪识别陪伴系统"""
    
    def __init__(self, gpt_api_key: str = None, gpt_base_url: str = None, mem0_api_key: str = None):
        # 初始化OpenAI客户端（用于GPT-3.5调用）
        self.client = OpenAI(
            api_key=gpt_api_key or GPT_API_KEY,
            base_url=gpt_base_url or GPT_BASE_URL
        )
        
        # 初始化mem0长期记忆系统（使用Platform API）
        mem0_api_key = mem0_api_key or MEM0_OPENAI_API_KEY
        # 用户ID将在运行时设置
        self.user_id = None
        self.memory = MemoryClient(api_key=mem0_api_key)
        
        # 短期记忆（上下文窗口）
        self.short_term_memory: List[ConversationTurn] = []
        self.max_short_term_memory = MAX_SHORT_TERM_MEMORY
        
        # 情绪标签映射
        self.emotion_map = {
            "NEUTRAL": "中性",
            "SAD": "伤心", 
            "ANGRY": "生气",
            "HAPPY": "高兴"
        }
        
        # 系统提示词
        self.system_prompt = """你是一个温暖、善解人意的AI陪伴助手。你的任务是：
        1. 认真倾听用户的每一句话
        2. 根据用户的情绪状态给予合适的回应
        3. 在用户情绪低落时提供安慰和支持
        4. 在用户生气时帮助冷静和疏导
        5. 在用户高兴时分享快乐
        6. 始终保持耐心、理解和关怀

        请用自然、温暖的语气与用户交流，避免过于正式或机械化的表达。"""
        
        print("情绪识别陪伴系统初始化完成！")
        print(f"📊 系统配置:")
        print(f"  短期记忆最大轮数: {self.max_short_term_memory}")
        print(f"  上下文滑动窗口大小: {CONTEXT_WINDOW_SIZE}")
        print("=" * 50)
    
    def analyze_emotion(self, user_input: str, context: str = "") -> Dict[str, Any]:
        """情绪识别工具"""
        try:
            # 记录开始时间
            start_time = time.time()
            
            # 构建情绪分析的输入
            analysis_input = f"用户输入: {user_input}"
            if context:
                analysis_input += f"\n上下文: {context}"
            
            response = self.client.chat.completions.create(
                model=GPT_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": """你是一个严格的文本情感分类器。只输出一个严格的String，不要输出多余文本、解释或反引号。
                        ## 你的任务
                        根据用户输入的文本，判断其表达的情感。
                        ## 输出要求
                        1. 输出必须为字符串，且仅包含以下字段："emotion": string
                        2. `emotion` 从 ["NEUTRAL", "SAD", "ANGRY", "HAPPY"] 中选择。
                        3. 若难以判断，统一判为"NEUTRAL"。
                        """
                    },
                    {
                        "role": "user",
                        "content": f"待分类文本：「{analysis_input}」"
                    }
                ],
            )
            
            # 计算响应时间
            gpt_response_time = time.time() - start_time
            
            # 解析响应
            result_text = response.choices[0].message.content
            try:
                result = json.loads(result_text)
            except json.JSONDecodeError:
                result = {"emotion": "NEUTRAL", "reason": "解析失败", "confidence": 0.0}
            
            return {
                'emotion': result.get('emotion', 'NEUTRAL'),
                'emotion_cn': self.emotion_map.get(result.get('emotion', 'NEUTRAL'), '中性'),
                'reason': result.get('reason', '无'),
                'confidence': result.get('confidence', 0.0),
                'gpt_response_time': round(gpt_response_time, 3)
            }
            
        except Exception as e:
            print(f"情绪分析失败: {e}")
            return {
                'emotion': 'NEUTRAL',
                'emotion_cn': '中性',
                'reason': '分析失败',
                'confidence': 0.0,
                'gpt_response_time': 0.0
            }
    
    def get_context_from_short_term_memory(self) -> str:
        """从短期记忆中获取上下文（滑动窗口）"""
        if not self.short_term_memory:
            return ""
        
        context_parts = []
        # 使用配置中的滑动窗口大小
        for turn in self.short_term_memory[-CONTEXT_WINDOW_SIZE:]:
            context_parts.append(f"用户: {turn.user_input}")
            context_parts.append(f"助手: {turn.model_response}")
            context_parts.append(f"情绪: {turn.emotion}")
        
        return "\n".join(context_parts)
    
    def search_related_memories(self, user_input: str, emotion: str) -> Dict[str, Any]:
        """搜索相关记忆"""
        if not self.user_id:
            return {
                'memories': [],
                'mem0_response_time': 0.0
            }
            
        try:
            # 记录开始时间
            start_time = time.time()
            
            # 构建多种搜索查询策略
            search_queries = [
                # 1. 基于情绪和内容的组合搜索
                f"用户情绪: {emotion}, 内容: {user_input}",
                # 2. 基于情绪搜索
                f"情绪: {emotion}",
                # 3. 基于内容关键词搜索
                user_input,
                # 4. 基于相似话题搜索
                f"类似话题: {user_input}"
            ]
            
            all_memories = []
            
            # 使用Platform API搜索相关记忆
            filters = {
                "OR": [
                    {
                        "user_id": self.user_id
                    }
                ]
            }
            
            # 尝试不同的搜索查询
            for query in search_queries:
                try:
                    results = self.memory.search(query, version="v2", filters=filters)
                    if results and results.get('results'):
                        all_memories.extend(results.get('results', []))
                except Exception as e:
                    print(f"搜索查询 '{query}' 失败: {e}")
                    continue
            
            # 去重并限制结果数量
            unique_memories = []
            seen_ids = set()
            for memory in all_memories:
                memory_id = memory.get('id', str(memory))
                if memory_id not in seen_ids:
                    seen_ids.add(memory_id)
                    unique_memories.append(memory)
                    if len(unique_memories) >= 5:  # 限制最多5条相关记忆
                        break
            
            # 计算响应时间
            mem0_response_time = time.time() - start_time
            
            return {
                'memories': unique_memories,
                'mem0_response_time': round(mem0_response_time, 3)
            }
            
        except Exception as e:
            print(f"搜索记忆失败: {e}")
            return {
                'memories': [],
                'mem0_response_time': 0.0
            }
    
    def store_memory(self, user_input: str, emotion: str, model_response: str) -> str:
        """存储记忆到长期记忆系统"""
        if not self.user_id:
            return str(uuid.uuid4())
            
        try:
            # 构建消息格式（Platform API 需要 messages 格式）
            messages = [
                {
                    "role": "user", 
                    "content": f"用户说: {user_input}，情绪: {emotion}"
                },
                {
                    "role": "assistant", 
                    "content": model_response
                }
            ]
            
            # 存储到mem0（使用Platform API）
            response = self.memory.add(
                messages=messages,
                user_id=self.user_id,
                metadata={
                    "emotion": emotion,
                    "timestamp": datetime.now().isoformat(),
                    "user_input": user_input,
                    "model_response": model_response
                }
            )
            
            # 返回记忆ID（从响应中提取）
            memory_id = response.get('id', str(uuid.uuid4())) if response else str(uuid.uuid4())
            return memory_id
            
        except Exception as e:
            print(f"存储记忆失败: {e}")
            return str(uuid.uuid4())
    
    def generate_response(self, user_input: str, emotion_info: Dict, related_memories: List[Dict]) -> Dict[str, Any]:
        """根据相关记忆生成回应"""
        try:
            # 记录开始时间
            start_time = time.time()
            
            # 构建系统提示词
            system_content = self.system_prompt
            
            # 如果有相关记忆，添加到系统提示词中
            if related_memories:
                memory_context = "相关历史记忆（请参考这些记忆来提供更个性化的回应）:\n"
                for i, memory in enumerate(related_memories[:3], 1):
                    # Platform API 可能返回不同的数据结构
                    memory_text = memory.get('memory', '') or memory.get('content', '') or str(memory)
                    memory_context += f"{i}. {memory_text}\n"
                
                memory_context += "\n请基于以上相关记忆，结合用户当前的情绪状态，提供更贴心和个性化的回应。"
                system_content += f"\n\n{memory_context}"
            else:
                system_content += "\n\n这是用户第一次提到这个话题，请提供温暖、贴心的回应。"
            
            # 构建用户消息
            user_content = f"用户当前情绪: {emotion_info['emotion_cn']} (置信度: {emotion_info['confidence']:.2f})\n"
            user_content += f"情绪分析依据: {emotion_info['reason']}\n"
            user_content += f"用户输入: {user_input}"
            
            response = self.client.chat.completions.create(
                model=GPT_MODEL,
                messages=[
                    {"role": "system", "content": system_content},
                    {"role": "user", "content": user_content}
                ],
                temperature=TEMPERATURE,
                max_tokens=MAX_TOKENS
            )
            
            # 计算响应时间
            response_time = time.time() - start_time
            
            return {
                'content': response.choices[0].message.content,
                'response_time': round(response_time, 3)
            }
            
        except Exception as e:
            print(f"生成回应失败: {e}")
            return {
                'content': "抱歉，我现在无法回应。请稍后再试。",
                'response_time': 0.0
            }
    
    def process_user_input(self, user_input: str) -> Dict[str, Any]:
        """处理用户输入的主流程"""
        # 1. 获取短期记忆上下文
        context = self.get_context_from_short_term_memory()
        
        # 2. 根据上下文窗口进行情绪识别
        emotion_info = self.analyze_emotion(user_input, context)
        
        # 3. 查找是否有相关的记忆（基于当前情绪和输入内容）
        memory_search_result = {'memories': [], 'mem0_response_time': 0.0}
        # 对于所有情绪都搜索相关记忆，不仅仅是负面情绪
        memory_search_result = self.search_related_memories(user_input, emotion_info['emotion'])
        related_memories = memory_search_result['memories']
        
        # 4. 根据相关记忆生成回应
        response_result = self.generate_response(user_input, emotion_info, related_memories)
        model_response = response_result['content']
        response_time = response_result['response_time']
        
        # 5. 创建对话轮次
        turn = ConversationTurn(
            user_input=user_input,
            model_response=model_response,
            emotion=emotion_info['emotion'],
            emotion_reason=emotion_info['reason'],
            timestamp=datetime.now(),
            turn_id=str(uuid.uuid4())
        )
        
        # 6. 更新短期记忆
        self.short_term_memory.append(turn)
        if len(self.short_term_memory) > self.max_short_term_memory:
            self.short_term_memory.pop(0)
        
        # 7. 最后把当前的记忆存放到长期记忆系统
        memory_id = self.store_memory(user_input, emotion_info['emotion'], model_response)
        
        return {
            'user_input': user_input,
            'model_response': model_response,
            'emotion': emotion_info,
            'related_memories': related_memories,
            'memory_id': memory_id,
            'turn_id': turn.turn_id,
            'timestamp': turn.timestamp.isoformat(),
            'response_times': {
                'gpt_emotion_analysis': emotion_info.get('gpt_response_time', 0.0),
                'mem0_memory_search': memory_search_result.get('mem0_response_time', 0.0),
                'gpt_response_generation': response_time
            }
        }
    
    def get_memory_summary(self) -> Dict[str, Any]:
        """获取记忆摘要"""
        if not self.user_id:
            return {'total_memories': 0, 'emotion_distribution': {}, 'recent_memories': []}
            
        try:
            # 使用Platform API获取所有记忆
            filters = {
                "OR": [
                    {
                        "user_id": self.user_id
                    }
                ]
            }
            
            response = self.memory.get_all(filters=filters)
            all_memories = response.get('results', []) if response else []
            
            # 统计情绪分布
            emotion_counts = {}
            for memory in all_memories:
                emotion = memory.get('metadata', {}).get('emotion', 'UNKNOWN')
                emotion_counts[emotion] = emotion_counts.get(emotion, 0) + 1
            
            return {
                'total_memories': len(all_memories),
                'emotion_distribution': emotion_counts,
                'recent_memories': all_memories[-5:] if all_memories else []
            }
            
        except Exception as e:
            print(f"获取记忆摘要失败: {e}")
            return {'total_memories': 0, 'emotion_distribution': {}, 'recent_memories': []}
    
    def show_conversation_history(self, limit: int = 10) -> None:
        """显示最近的对话历史"""
        if not self.short_term_memory:
            print("📝 暂无对话历史")
            return
        
        print(f"\n📚 最近 {min(limit, len(self.short_term_memory))} 轮对话历史:")
        print("=" * 60)
        
        # 显示最近的对话
        recent_turns = self.short_term_memory[-limit:] if limit > 0 else self.short_term_memory
        
        for i, turn in enumerate(recent_turns, 1):
            print(f"\n第 {len(self.short_term_memory) - len(recent_turns) + i} 轮对话:")
            print(f"⏰ 时间: {turn.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"😊 情绪: {self.emotion_map.get(turn.emotion, turn.emotion)} (置信度: {turn.emotion_reason})")
            print(f"👤 您: {turn.user_input}")
            print(f"🤖 助手: {turn.model_response}")
            print("-" * 40)
        
        print(f"\n📊 历史统计:")
        print(f"总对话轮数: {len(self.short_term_memory)}")
        
        # 统计情绪分布
        emotion_counts = {}
        for turn in self.short_term_memory:
            emotion_counts[turn.emotion] = emotion_counts.get(turn.emotion, 0) + 1
        
        print("情绪分布:")
        for emotion, count in emotion_counts.items():
            emotion_cn = self.emotion_map.get(emotion, emotion)
            print(f"  {emotion_cn}: {count} 次")
    
    def run_interactive_session(self):
        """运行交互式会话"""
        print("🤖 情绪识别陪伴系统启动")
        print("=" * 50)
        
        # 获取用户ID
        while True:
            user_id = input("请输入您的用户ID: ").strip()
            if user_id:
                self.user_id = user_id
                print(f"✅ 用户ID已设置为: {user_id}")
                break
            else:
                print("❌ 用户ID不能为空，请重新输入")
        
        print(f"\n👤 当前用户: {self.user_id}")
        print("\n📋 可用命令:")
        print("输入 'quit' 退出，输入 'summary' 查看记忆摘要")
        print("输入 'history' 查看对话历史，输入 'clear' 清空短期记忆")
        print("输入 'user' 切换用户ID")
        print("=" * 50)
        
        while True:
            try:
                user_input = input("\n您: ").strip()
                
                if user_input.lower() == 'quit':
                    print("👋 再见！感谢您的陪伴！")
                    break
                elif user_input.lower() == 'summary':
                    summary = self.get_memory_summary()
                    print(f"\n📊 记忆摘要:")
                    print(f"总记忆数: {summary['total_memories']}")
                    print(f"情绪分布: {summary['emotion_distribution']}")
                    if summary['recent_memories']:
                        print("最近记忆:")
                        for memory in summary['recent_memories']:
                            # Platform API 可能返回不同的数据结构
                            memory_text = memory.get('memory', '') or memory.get('content', '') or str(memory)
                            print(f"  - {memory_text[:50]}...")
                    continue
                elif user_input.lower() == 'clear':
                    self.short_term_memory.clear()
                    print("✅ 短期记忆已清空")
                    continue
                elif user_input.lower() == 'user':
                    # 切换用户ID
                    while True:
                        new_user_id = input("请输入新的用户ID: ").strip()
                        if new_user_id:
                            self.user_id = new_user_id
                            print(f"✅ 用户ID已切换为: {new_user_id}")
                            print("💡 注意：切换用户后，记忆将基于新的用户ID进行存储和检索")
                            break
                        else:
                            print("❌ 用户ID不能为空，请重新输入")
                    continue
                elif not user_input:
                    continue
                
                # 处理用户输入
                result = self.process_user_input(user_input)
                
                # 显示结果
                print(f"\n🤖 助手: {result['model_response']}")
                print(f"😊 检测到情绪: {result['emotion']['emotion_cn']} (置信度: {result['emotion']['confidence']:.2f})")
                print(f"💭 分析依据: {result['emotion']['reason']}")
                
                # 显示响应时间
                response_times = result.get('response_times', {})
                if response_times:
                    print(f"\n⏱️  响应时间:")
                    if response_times.get('gpt_emotion_analysis', 0) > 0:
                        print(f"  GPT情绪分析: {response_times['gpt_emotion_analysis']}秒")
                    if response_times.get('mem0_memory_search', 0) > 0:
                        print(f"  Mem0记忆搜索: {response_times['mem0_memory_search']}秒")
                    if response_times.get('gpt_response_generation', 0) > 0:
                        print(f"  GPT回复生成: {response_times['gpt_response_generation']}秒")
                    
                    # 计算总响应时间
                    total_time = sum([
                        response_times.get('gpt_emotion_analysis', 0),
                        response_times.get('mem0_memory_search', 0),
                        response_times.get('gpt_response_generation', 0)
                    ])
                    print(f"  总响应时间: {round(total_time, 3)}秒")
                
                # 如果有相关记忆，显示
                if result['related_memories']:
                    print(f"\n🔍 找到 {len(result['related_memories'])} 条相关记忆:")
                    for i, memory in enumerate(result['related_memories'][:2], 1):
                        # Platform API 可能返回不同的数据结构
                        memory_text = memory.get('memory', '') or memory.get('content', '') or str(memory)
                        print(f"  {i}. {memory_text[:100]}...")
                
                print("-" * 50)
                
            except KeyboardInterrupt:
                print("\n👋 再见！感谢您的陪伴！")
                break
            except Exception as e:
                print(f"❌ 处理出错: {e}")
                continue

if __name__ == "__main__":
    # 创建系统实例
    companion = EmotionCompanionSystem()
    
    # 运行交互式会话
    companion.run_interactive_session()
