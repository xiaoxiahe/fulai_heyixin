import os
import glob
import time
import asyncio
import statistics
import unicodedata
from typing import Dict, List, Tuple

from sauc_websocket_demo import AsrWsClient, extract_text


POSSIBLE_AUDIO_FOLDERS = [
     r"D:\shixi\fulai\emotion_code\emotion_data\audio\angry",
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\happy",
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\neutral",
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\sad",
]


def load_labels_from_folder(folder: str) -> Dict[str, str]:
    """读取目录下所有 .txt 标注，构建 音频ID(不含后缀) -> 文本 的映射。

    支持两种前缀格式：
    1) Elderly0011S0005W0133\t文本
    2) 50：Elderly0011S0005W0133\t文本（注意全角冒号）
    """
    label_map: Dict[str, str] = {}
    txt_files = glob.glob(os.path.join(folder, "*.txt"))
    for txt in txt_files:
        try:
            with open(txt, "r", encoding="utf-8") as f:
                for line in f:
                    raw = line.strip()
                    if not raw:
                        continue
                    # 拆分为 [left, text]
                    if "\t" not in raw:
                        continue
                    left, text = raw.split("\t", 1)
                    left = left.strip()
                    # 兼容可能的"50：ID"或"50:ID"形式
                    if "：" in left:
                        left = left.split("：", 1)[-1].strip()
                    elif ":" in left:
                        left = left.split(":", 1)[-1].strip()
                    if left:
                        label_map[left] = text.strip()
        except Exception:
            # 单个文件失败不影响整体
            pass
    return label_map


async def recognize_once(url: str, seg_duration_ms: int, wav_path: str) -> Tuple[str, int]:
    """识别单个音频，返回(最终文本, 用时ms)。"""
    # 移除这里的 start_ts，因为流式时间记录已经在 AsrWsClient 内部处理
    final_text = ""
    async with AsrWsClient(url, seg_duration_ms) as client:
        async for response in client.execute(wav_path):
            text = extract_text(response.payload_msg)
            if text:
                final_text = text
    
    # 从客户端获取流式时间信息
    if hasattr(client, 'stream_start_time') and hasattr(client, 'stream_end_time'):
        if client.stream_start_time and client.stream_end_time:
            elapsed_ms = int((client.stream_end_time - client.stream_start_time) * 1000)
            # logger.info(f"流式识别耗时（音频发送到首次响应）: {elapsed_ms} ms") # Original code had this line commented out
        else:
            elapsed_ms = -1  # 时间记录不完整
            # logger.warning("流式时间记录不完整") # Original code had this line commented out
    else:
        elapsed_ms = -1  # 无法获取时间信息
        # logger.warning("无法获取流式时间信息") # Original code had this line commented out
    
    return final_text, elapsed_ms


def calc_percentile(data: List[int], p: float) -> float:
    if not data:
        return 0.0
    data_sorted = sorted(data)
    k = (len(data_sorted) - 1) * p
    f = int(k)
    c = min(f + 1, len(data_sorted) - 1)
    if f == c:
        return float(data_sorted[f])
    return data_sorted[f] + (data_sorted[c] - data_sorted[f]) * (k - f)


def remove_punctuation(text: str) -> str:
    if not text:
        return ""
    # 去除所有 Unicode 标点字符，保留字母数字及空白
    return "".join(ch for ch in text if not unicodedata.category(ch).startswith("P"))


def levenshtein_distance(a: str, b: str) -> int:
    # 经典DP实现，按字符计算
    if a == b:
        return 0
    if len(a) == 0:
        return len(b)
    if len(b) == 0:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i]
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            curr.append(min(
                curr[-1] + 1,       # insertion
                prev[j] + 1,         # deletion
                prev[j - 1] + cost   # substitution
            ))
        prev = curr
    return prev[-1]


def char_accuracy_ignore_punct(pred: str, truth: str) -> float:
    pred_n = remove_punctuation(pred or "")
    truth_n = remove_punctuation(truth or "")
    if len(truth_n) == 0:
        return 1.0 if len(pred_n) == 0 else 0.0
    dist = levenshtein_distance(pred_n, truth_n)
    cer = dist / max(1, len(truth_n))
    acc = 1.0 - cer
    return max(0.0, min(1.0, acc))


async def main():
    import argparse

    parser = argparse.ArgumentParser(description="Batch evaluate SAUC recognition vs labels")
    parser.add_argument("--url", type=str, default="wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_nostream",
                        help="WebSocket URL")
    parser.add_argument("--seg-duration", type=int, default=200,
                        help="Audio duration(ms) per packet, default:200")
    args = parser.parse_args()

    url = args.url
    seg_ms = args.seg_duration

    results: List[Tuple[str, str, str, int, float]] = []  # (file, asr, gt, ms, acc)
    latencies: List[int] = []
    total = 0
    acc_list: List[float] = []

    for folder in POSSIBLE_AUDIO_FOLDERS:
        if not os.path.isdir(folder):
            continue
        labels = load_labels_from_folder(folder)
        wav_files = glob.glob(os.path.join(folder, "*.wav"))
        for wav_path in wav_files:
            base = os.path.splitext(os.path.basename(wav_path))[0]
            gt = labels.get(base, "")
            try:
                asr, ms = await recognize_once(url, seg_ms, wav_path)
            except Exception as e:
                asr, ms = "", -1
            norm_asr = asr.strip()
            norm_gt = gt.strip()
            acc = char_accuracy_ignore_punct(norm_asr, norm_gt)
            results.append((base, norm_asr, norm_gt, ms, acc))
            if ms >= 0:
                latencies.append(ms)
            total += 1
            acc_list.append(acc)

    # 输出逐条结果（表格对齐）
    def sanitize(s: str) -> str:
        return (s or "").replace("\n", " ").replace("\r", " ")

    headers = ["文件", "用时(ms)", "准确率(忽略标点)", "识别", "标注"]
    rows = []
    for base, asr, gt, ms, acc in results:
        rows.append([
            sanitize(base),
            str(ms if ms >= 0 else "-"),
            f"{acc:.2%}",
            sanitize(asr),
            sanitize(gt),
        ])

    # 动态计算列宽（设定合理的最大宽度防止一行太长）
    max_col_width = [
        40,   # 文件
        10,   # 用时
        14,   # 准确率
        80,   # 识别
        80,   # 标注
    ]
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = min(max(col_widths[i], len(cell)), max_col_width[i])

    def fmt_row(row_vals: list) -> str:
        parts = []
        for i, cell in enumerate(row_vals):
            text = cell
            if len(text) > col_widths[i]:
                text = text[: max(0, col_widths[i] - 1)] + "…"
            align = ">" if headers[i] in ("用时(ms)", "准确率(忽略标点)") else "<"
            parts.append(f"{text:{align}{col_widths[i]}}")
        return "  |  ".join(parts)

    header_line = fmt_row(headers)
    sep_line = "-" * len(header_line)
    print(header_line)
    print(sep_line)
    for r in rows:
        print(fmt_row(r))

    # 统计
    avg_ms = int(statistics.mean(latencies)) if latencies else 0
    p50_ms = int(calc_percentile(latencies, 0.50)) if latencies else 0
    p95_ms = int(calc_percentile(latencies, 0.95)) if latencies else 0
    avg_acc = float(statistics.mean(acc_list)) if acc_list else 0.0

    print()
    print("统计汇总")
    print("-" * 20)
    print(f"平均用时(ms): {avg_ms}")
    print(f"P50 用时(ms): {p50_ms}")
    print(f"P95 用时(ms): {p95_ms}")
    print(f"总体字符级准确率(忽略标点): {avg_acc:.2%}  样本数: {total}")


if __name__ == "__main__":
    asyncio.run(main())


