#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
火山流式识别 - 正确记录流式时间
流式开始时间：第一个音频片段发送时
流式结束时间：收到最后一个响应时
"""

import json
import time
import uuid
import asyncio
import aiohttp
import logging
from typing import AsyncGenerator, Optional, Tuple

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HuoshanStreamRecognizer:
    """火山流式识别器"""
    
    def __init__(self, app_id: str, access_token: str, resource_id: str = "volc.bigasr.auc_turbo"):
        self.app_id = app_id
        self.access_token = access_token
        self.resource_id = resource_id
        self.websocket_url = "wss://openspeech.bytedance.com/api/v3/sauc/bigmodel"
        
        # 流式时间记录
        self.stream_start_time: Optional[float] = None
        self.stream_end_time: Optional[float] = None
        self.first_audio_sent = False
        self.last_response_received = False
        
        # WebSocket 连接
        self.conn: Optional[aiohttp.ClientWebSocketResponse] = None
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def __aenter__(self):
        """异步上下文管理器入口"""
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        if self.conn:
            await self.conn.close()
        if self.session:
            await self.session.close()
    
    async def create_connection(self):
        """创建WebSocket连接"""
        try:
            # 构建连接URL
            params = {
                "app_id": self.app_id,
                "access_token": self.access_token,
                "resource_id": self.resource_id,
                "request_id": str(uuid.uuid4()),
                "sequence": "-1"
            }
            
            query_string = "&".join([f"{k}={v}" for k, v in params.items()])
            full_url = f"{self.websocket_url}?{query_string}"
            
            logger.info(f"连接到WebSocket: {full_url}")
            self.conn = await self.session.ws_connect(full_url)
            logger.info("WebSocket连接成功")
            
        except Exception as e:
            logger.error(f"WebSocket连接失败: {e}")
            raise
    
    async def send_audio_segments(self, audio_data: bytes, segment_duration_ms: int = 200) -> AsyncGenerator[None, None]:
        """发送音频片段"""
        # 计算分段大小 (假设16kHz采样率，16bit)
        sample_rate = 16000
        bytes_per_sample = 2
        segment_size = int(sample_rate * bytes_per_sample * segment_duration_ms / 1000)
        
        segments = []
        for i in range(0, len(audio_data), segment_size):
            end = min(i + segment_size, len(audio_data))
            segments.append(audio_data[i:end])
        
        logger.info(f"音频分段: {len(segments)} 段，每段 {segment_duration_ms}ms")
        
        for i, segment in enumerate(segments):
            is_last = (i == len(segments) - 1)
            
            # 记录第一个音频片段发送的时间作为流式开始时间
            if not self.first_audio_sent:
                self.stream_start_time = time.perf_counter()
                self.first_audio_sent = True
                logger.info(f"流式识别开始时间记录: {self.stream_start_time}")
            
            # 构建请求
            request = {
                "type": "audio",
                "data": segment.hex(),  # 转换为十六进制字符串
                "is_last": is_last
            }
            
            await self.conn.send_json(request)
            logger.info(f"发送音频段 {i+1}/{len(segments)} (最后: {is_last})")
            
            # 模拟实时流，等待一段时间
            await asyncio.sleep(segment_duration_ms / 1000)
            yield
    
    async def receive_responses(self) -> AsyncGenerator[dict, None]:
        """接收识别响应"""
        try:
            async for msg in self.conn:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    response = json.loads(msg.data)
                    logger.info(f"收到响应: {json.dumps(response, indent=2, ensure_ascii=False)}")
                    
                    # 检查是否是最后一个响应
                    if response.get("is_final", False) or response.get("code", 0) != 0:
                        self.last_response_received = True
                        self.stream_end_time = time.perf_counter()
                        logger.info(f"流式识别结束时间记录: {self.stream_end_time}")
                        
                        if self.stream_start_time:
                            stream_duration = (self.stream_end_time - self.stream_start_time) * 1000
                            logger.info(f"流式识别实际耗时: {stream_duration:.2f} ms")
                    
                    yield response
                    
                    if response.get("is_final", False) or response.get("code", 0) != 0:
                        break
                        
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(f"WebSocket错误: {msg.data}")
                    break
                elif msg.type == aiohttp.WSMsgType.CLOSED:
                    logger.info("WebSocket连接已关闭")
                    break
                    
        except Exception as e:
            logger.error(f"接收响应时出错: {e}")
            raise
    
    async def recognize_stream(self, audio_file_path: str, segment_duration_ms: int = 200) -> AsyncGenerator[dict, None]:
        """流式识别主流程"""
        try:
            # 1. 读取音频文件
            with open(audio_file_path, 'rb') as f:
                audio_data = f.read()
            logger.info(f"读取音频文件: {audio_file_path}, 大小: {len(audio_data)} 字节")
            
            # 2. 创建WebSocket连接
            await self.create_connection()
            
            # 3. 启动音频发送和响应接收
            sender_task = asyncio.create_task(self._run_sender(audio_data, segment_duration_ms))
            
            try:
                async for response in self.receive_responses():
                    yield response
            finally:
                sender_task.cancel()
                try:
                    await sender_task
                except asyncio.CancelledError:
                    pass
                    
        except Exception as e:
            logger.error(f"流式识别失败: {e}")
            raise
    
    async def _run_sender(self, audio_data: bytes, segment_duration_ms: int):
        """运行音频发送器"""
        async for _ in self.send_audio_segments(audio_data, segment_duration_ms):
            pass
    
    def get_stream_duration_ms(self) -> Optional[int]:
        """获取流式识别耗时（毫秒）"""
        if self.stream_start_time and self.stream_end_time:
            return int((self.stream_end_time - self.stream_start_time) * 1000)
        return None

async def main():
    """主函数示例"""
    import argparse
    
    parser = argparse.ArgumentParser(description="火山流式识别 - 正确记录流式时间")
    parser.add_argument("--file", type=str, required=True, help="音频文件路径")
    parser.add_argument("--app-id", type=str, required=True, help="火山应用ID")
    parser.add_argument("--access-token", type=str, required=True, help="火山访问令牌")
    parser.add_argument("--seg-duration", type=int, default=200, help="音频分段时长(ms)，默认200ms")
    
    args = parser.parse_args()
    
    # 创建流式识别器
    recognizer = HuoshanStreamRecognizer(
        app_id=args.app_id,
        access_token=args.access_token
    )
    
    async with recognizer:
        final_text = ""
        try:
            async for response in recognizer.recognize_stream(args.file, args.seg_duration):
                # 提取文本
                if "text" in response:
                    final_text = response["text"]
                    logger.info(f"识别文本: {final_text}")
                
                # 检查是否完成
                if response.get("is_final", False):
                    break
                    
        except Exception as e:
            logger.error(f"识别过程出错: {e}")
    
    # 输出结果
    print(f"\n====== 识别结果 ======")
    print(f"最终文本: {final_text}")
    
    # 输出流式时间信息
    duration_ms = recognizer.get_stream_duration_ms()
    if duration_ms is not None:
        print(f"流式识别耗时: {duration_ms} ms")
        print(f"流式开始时间: {recognizer.stream_start_time}")
        print(f"流式结束时间: {recognizer.stream_end_time}")
    else:
        print("流式时间记录不完整")

if __name__ == "__main__":
    asyncio.run(main())

