### 项目说明

本仓库包含多家语音/文本模型的评估与演示脚本。下表概述每个 Python 脚本所评估/调用的模型（或服务）及用途，便于快速定位与复现。

### 脚本与对应模型/服务

- **sauc_websocket_demo.py**
  - **模型/服务**: 火山引擎 SAUC BigModel（v3，WebSocket 流式/非流式可切）
  - **端点/线索**: `wss://openspeech.bytedance.com/api/v3/sauc/bigmodel`（示例亦含 `_async`/`_nostream`）；`model_name: "bigmodel"`
  - **用途**: 流式客户端，含完整帧协议打包与响应解析；可单条文件测试

- **batch_eval_sauc.py**
  - **模型/服务**: 火山引擎 SAUC BigModel（v3，非流式评估）
  - **端点/线索**: 默认 `wss://openspeech.bytedance.com/api/v3/sauc/bigmodel_nostream`
  - **用途**: 批量评估识别结果，统计耗时分位与字符级准确率（忽略标点）

- **huoshan_stream.py**
  - **模型/服务**: 火山引擎 SAUC BigModel（v3，WebSocket 流式）
  - **端点/线索**: `wss://openspeech.bytedance.com/api/v3/sauc/bigmodel`
  - **用途**: 流式识别，严格记录“首包发送→首响接收/最终响应”的时序与耗时

- **streaming_asr_demo.py**
  - **模型/服务**: 火山引擎 一句话识别/ASR v2（WebSocket，短语音）
  - **端点/线索**: `wss://openspeech.bytedance.com/api/v2/asr`；脚本顶部注释“火山一句话识别”
  - **用途**: 遍历情感目录批量识别，提取文本并做字符级准确率统计

- **huoshan_quik.py**
  - **模型/服务**: 火山引擎 AUC BigModel Flash（极速版，HTTP REST 非流式）
  - **端点/线索**: `POST https://openspeech.bytedance.com/api/v3/auc/bigmodel/recognize/flash`，`X-Api-Resource-Id: volc.bigasr.auc_turbo`
  - **用途**: 单条快速识别示例（本地文件Base64/URL）

- **batch_eval_huoshan.py**
  - **模型/服务**: 火山引擎 AUC BigModel Flash（HTTP REST 批量评估）
  - **端点/线索**: 同上 `recognize/flash`，`model_name: "bigmodel"`
  - **用途**: 批量遍历本地音频，统计用时分位与字符级准确率

- **aliyun_a_sentence.py**
  - **模型/服务**: 阿里云智能语音交互 NLS ASR（REST 接口）
  - **端点/线索**: 取 Token 后调用 `https://nls-gateway-cn-shanghai.aliyuncs.com/stream/v1/asr`
  - **用途**: 从本地文件名构造远端 URL，逐条识别并对比标注，统计耗时/相似度

- **emotion_based_text.py**
  - **模型/服务**: 豆包大模型 `doubao-seed-1.6-250615`（文本情感分类）
  - **端点/线索**: 通过 `volcenginesdkarkruntime` 的 `Ark().chat.completions.create`
  - **用途**: 对 Excel 文本集进行情感分类评估，输出准确率/召回率与耗时分位
  
### 备注
- 含有 `appid`/`token`/`access_key` 等配置的脚本仅示例用途，实际运行请改为环境变量或配置文件，并注意密钥安全。
- 不同脚本的“短语音/流式/非流式”模式不同，请以“端点/线索”中 URL 与注释为准。
