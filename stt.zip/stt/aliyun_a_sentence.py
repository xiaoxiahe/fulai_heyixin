# -*- coding: UTF-8 -*-
import os
import json
import sys
import requests
from urllib.parse import urljoin, quote, unquote
from pathlib import Path
import time
from typing import Union, Sequence
import difflib

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

# ------------ 阿里云配置------------
ACCESS_KEY_ID = "LTAI5tEPCmkXpU2SFUwzQZhc"
ACCESS_KEY_SECRET = "FIzqELqyKZDAnLtBVYDaAST3fXMJuY"
APPKEY = "otbZBU7n1J5m5XMt"
REGION = "cn-shanghai"
TOKEN_ENDPOINT = "nls-meta.cn-shanghai.aliyuncs.com"

# 识别 REST 接口
ASR_URL = "https://nls-gateway-cn-shanghai.aliyuncs.com/stream/v1/asr"

# ------------ 本地与远端文件映射 ------------
base_url = ["https://cdn.fulai.tech/tmp/audio/emotion_labled/happy/" ,
            "https://cdn.fulai.tech/tmp/audio/emotion_labled/angry/" ,
            "https://cdn.fulai.tech/tmp/audio/emotion_labled/sad/",
            "https://cdn.fulai.tech/tmp/audio/emotion_labled/neutral/" ,
            ] # 远端基地址
local_dir = ["D:/shixi/fulai/emotion_data/音频/对话音频/happy/" ,
             "D:/shixi/fulai/emotion_data/音频/对话音频/angry/" ,
             "D:/shixi/fulai/emotion_data/音频/对话音频/sad/" ,
             "D:/shixi/fulai/emotion_data/音频/对话音频/neutral/" ,

              ]         # 本地目录（仅用于遍历文件名）
extensions = (".wav", ".mp3", ".flac", ".pcm")                  # 可识别的扩展名
SAMPLE_RATE = 16000                                            # 确保与你的音频一致

# ------------ 获取 Token（阿里云 SDK） ------------
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest

def get_nls_token(access_key_id: str, access_key_secret: str, region: str = "cn-shanghai") -> str:
    client = AcsClient(access_key_id, access_key_secret, region)
    req = CommonRequest()
    req.set_domain(TOKEN_ENDPOINT)
    req.set_version("2019-02-28")
    req.set_action_name("CreateToken")
    req.set_method("POST")
    resp = client.do_action_with_exception(req)
    data = json.loads(resp)
    return data["Token"]["Id"]

# ------------ 识别单个 URL ------------
def pick_format_from_ext(url: str) -> str:
    """根据扩展名决定 format 参数"""
    suffix = Path(url.split("?")[0]).suffix.lower().lstrip(".")
    if suffix in {"wav", "pcm", "mp3"}:
        return suffix
    # 默认回落为 wav
    return "wav"

def asr_from_url_with_token(token: str, audio_url: str):
    # 1) 下载音频二进制
    r = requests.get(audio_url, timeout=60)
    r.raise_for_status()
    audio_bytes = r.content

    # 2) 识别参数
    fmt = pick_format_from_ext(audio_url)
    params = {
        "appkey": APPKEY,
        "format": fmt,
        "sample_rate": SAMPLE_RATE,
        "enable_punctuation_prediction": "true",
        "enable_inverse_text_normalization": "true",
        "enable_voice_detection": "false",
    }
    headers = {
        "X-NLS-Token": token,
        "Content-Type": "application/octet-stream",
    }

    # 3) 调用识别
    resp = requests.post(ASR_URL, params=params, headers=headers, data=audio_bytes, timeout=120)
    try:
        data = resp.json()
    except json.JSONDecodeError:
        return {"ok": False, "error": f"Non-JSON response ({resp.status_code}): {resp.text[:300]}"}

    if data.get("status") == 20000000:
        return {"ok": True, "result": data.get("result", ""), "raw": data}
    else:
        return {"ok": False, "error": data, "http": resp.status_code}

# ------------ 批量构造 URL 列表并处理 ------------
def build_remote_urls_from_local_names(local_dir, base_url, exts=extensions):
    """
    遍历本地目录，按文件名拼接远端 URL（自动URL编码，适配中文/空格）。

    支持以下入参形式：
    - local_dir: 字符串，或 字符串列表/元组
    - base_url: 字符串，或 字符串列表/元组
    若两者均为列表/元组，则按索引一一对应；长度不一致会抛出异常。
    """

    def collect_one(dir_path: str, base: str):
        collected = []
        for root, _, files in os.walk(dir_path):
            for name in files:
                if name.lower().endswith(exts):
                    safe_name = quote(name, safe="/-_.()!~*'")
                    collected.append(urljoin(base, safe_name))
        return collected

    urls = []
    is_dirs_list = isinstance(local_dir, (list, tuple))
    is_bases_list = isinstance(base_url, (list, tuple))

    if is_dirs_list or is_bases_list:
        if is_dirs_list and is_bases_list:
            if len(local_dir) != len(base_url):
                raise ValueError("local_dir 和 base_url 的列表长度不一致")
            for d, b in zip(local_dir, base_url):
                urls.extend(collect_one(d, b))
        elif is_dirs_list:
            for d in local_dir:
                urls.extend(collect_one(d, base_url))
        else:
            for b in base_url:
                urls.extend(collect_one(local_dir, b))
    else:
        urls = collect_one(local_dir, base_url)

    # 去重保持顺序
    seen = set()
    dedup = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            dedup.append(u)
    return dedup

# ------------ 加载标注文本（每个目录下的 .txt） ------------
def load_transcripts_from_dirs(directories: Union[str, Sequence[str]]):
    """从给定目录（或目录列表）加载所有 .txt 标注，返回字典：key -> transcript。

    key 规范化规则：去掉扩展名（若有），仅保留文件基名。例如：
    "foo/bar/Elderly0104S0052W0024.wav" 与 "Elderly0104S0052W0024" 都映射到同一 key。
    文本文件每行格式："文件名\t文本"；若遇到无制表符，则尝试第一个空白分割。
    多个目录、多份 txt 会合并；后出现的同 key 会覆盖之前的值。
    """
    if isinstance(directories, (list, tuple)):
        dirs = list(directories)
    else:
        dirs = [directories]

    key_to_text = {}
    for dir_path in dirs:
        if not dir_path or not os.path.isdir(dir_path):
            continue
        for name in os.listdir(dir_path):
            if name.lower().endswith('.txt'):
                txt_path = os.path.join(dir_path, name)
                try:
                    with open(txt_path, 'r', encoding='utf-8') as f:
                        for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            if '\t' in line:
                                key_part, text_part = line.split('\t', 1)
                            else:
                                parts = line.split(maxsplit=1)
                                if len(parts) == 2:
                                    key_part, text_part = parts
                                else:
                                    # 无法解析，跳过
                                    continue
                            base = os.path.basename(key_part)
                            base_no_ext = os.path.splitext(base)[0]
                            key_to_text[base_no_ext] = text_part.strip()
                except Exception:
                    # 读取失败不影响主流程
                    pass
    return key_to_text


def compute_text_similarity(reference: str, hypothesis: str) -> float:
    """使用字符级相似度近似准确率，返回 0..1。"""
    if reference is None or hypothesis is None:
        return 0.0
    reference = reference.strip()
    hypothesis = hypothesis.strip()
    if not reference and not hypothesis:
        return 1.0
    if not reference or not hypothesis:
        return 0.0
    return difflib.SequenceMatcher(a=reference, b=hypothesis).ratio()


def percentile(values, p: float) -> float:
    """百分位（0..100）。使用最近秩法，n>=1。"""
    if not values:
        return 0.0
    v = sorted(values)
    n = len(v)
    if p <= 0:
        return float(v[0])
    if p >= 100:
        return float(v[-1])
    # 最近秩：k = ceil(p/100 * n)
    import math
    k = max(1, min(n, math.ceil(p / 100.0 * n)))
    return float(v[k - 1])

if __name__ == "__main__":
    # 0) 基本校验
    if not ACCESS_KEY_ID or not ACCESS_KEY_SECRET or not APPKEY:
        raise RuntimeError("请配置 ACCESS_KEY_ID / ACCESS_KEY_SECRET / APPKEY（推荐用环境变量）")

    # 1) 获取 Token
    token = get_nls_token(ACCESS_KEY_ID, ACCESS_KEY_SECRET, REGION)
    print("Got Token OK.")

    # 2) 从本地文件名生成远端 URL 列表
    file_urls = build_remote_urls_from_local_names(local_dir, base_url, extensions)
    if not file_urls:
        print("未在本地目录中发现匹配的音频文件。请确认 local_dir 与 extensions 设置是否正确。")
        sys.exit(0)

    print(f"共发现 {len(file_urls)} 个文件。")
    print("URL 列表：")
    for i, u in enumerate(file_urls, 1):
        print(f"  [{i}] {u}")
    print("\n将开始识别...\n")

    # 2.5) 加载各目录下标注文本
    transcripts = load_transcripts_from_dirs(local_dir)

    # 3) 逐个识别并对比
    success = 0
    durations_all = []
    durations_ok = []
    similarities = []
    similarity_samples = 0
    for idx, url in enumerate(file_urls, 1):
        print(f"[{idx}/{len(file_urls)}] {url}")
        # 文件名键：从 URL 中提取未编码的文件名，去扩展名
        url_path_part = url.split('?')[0]
        file_name_encoded = os.path.basename(url_path_part)
        file_name = unquote(file_name_encoded)
        file_key = os.path.splitext(file_name)[0]

        try:
            start_t = time.perf_counter()
            result = asr_from_url_with_token(token, url)
            elapsed = time.perf_counter() - start_t
            durations_all.append(elapsed)

            ref_text = transcripts.get(file_key)
            if result["ok"]:
                hyp_text = result.get("result", "")
                print(f"  -> 真实文本: {ref_text if ref_text is not None else '(无标注)'}")
                print(f"  -> 识别文本: {hyp_text}")
                if ref_text is not None and ref_text.strip():
                    sim = compute_text_similarity(ref_text, hyp_text or "")
                    similarities.append(sim)
                    similarity_samples += 1
                    print(f"  -> 准确率(字符级相似度): {sim:.3f}")
                else:
                    print("  -> 无标注，跳过准确率统计")
                print(f"  -> 用时: {elapsed:.3f}s")
                success += 1
                durations_ok.append(elapsed)
            else:
                print("  -> 真实文本:", ref_text if ref_text is not None else '(无标注)')
                print("  -> 识别失败:", result.get("error"))
                print(f"  -> 用时: {elapsed:.3f}s")
        except requests.HTTPError as e:
            print("  -> HTTPError:", e)
        except Exception as e:
            print("  -> Error:", repr(e))
        print("-" * 70)

    print(f"\n完成。成功 {success}/{len(file_urls)} 个。")
    if similarities:
        avg_acc = sum(similarities) / len(similarities)
        print(f"平均准确率(字符级相似度): {avg_acc:.3f}（样本数: {len(similarities)}）")
    if durations_all:
        total_time = sum(durations_all)
        avg_time = total_time / len(durations_all)
        p50 = percentile(durations_all, 50)
        p95 = percentile(durations_all, 95)
        print(f"总耗时: {total_time:.3f}s，平均每条: {avg_time:.3f}s")
        print(f"耗时-50分位: {p50:.3f}s，耗时-95分位: {p95:.3f}s")
    if durations_ok:
        avg_ok = sum(durations_ok) / len(durations_ok)
        print(f"成功条目平均耗时: {avg_ok:.3f}s")
