import os
import glob
import time
import asyncio
import statistics
import unicodedata
from typing import Dict, List, Tuple

import json
import uuid
import requests
import base64


POSSIBLE_AUDIO_FOLDERS = [
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\angry",
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\happy",
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\neutral",
    r"D:\shixi\fulai\emotion_code\emotion_data\audio\sad",
]


def file_to_base64(file_path: str) -> str:
    with open(file_path, 'rb') as f:
        return base64.b64encode(f.read()).decode('utf-8')


def load_labels_from_folder(folder: str) -> Dict[str, str]:
    label_map: Dict[str, str] = {}
    for txt in glob.glob(os.path.join(folder, "*.txt")):
        try:
            with open(txt, "r", encoding="utf-8") as f:
                for line in f:
                    raw = line.strip()
                    if not raw or "\t" not in raw:
                        continue
                    left, text = raw.split("\t", 1)
                    left = left.strip()
                    if "：" in left:
                        left = left.split("：", 1)[-1].strip()
                    elif ":" in left:
                        left = left.split(":", 1)[-1].strip()
                    if left:
                        label_map[left] = text.strip()
        except Exception:
            pass
    return label_map


def remove_punctuation(text: str) -> str:
    if not text:
        return ""
    return "".join(ch for ch in text if not unicodedata.category(ch).startswith("P"))


def levenshtein_distance(a: str, b: str) -> int:
    if a == b:
        return 0
    if len(a) == 0:
        return len(b)
    if len(b) == 0:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i]
        for j, cb in enumerate(b, 1):
            cost = 0 if ca == cb else 1
            curr.append(min(
                curr[-1] + 1,
                prev[j] + 1,
                prev[j - 1] + cost
            ))
        prev = curr
    return prev[-1]


def char_accuracy_ignore_punct(pred: str, truth: str) -> float:
    pred_n = remove_punctuation(pred or "")
    truth_n = remove_punctuation(truth or "")
    if len(truth_n) == 0:
        return 1.0 if len(pred_n) == 0 else 0.0
    dist = levenshtein_distance(pred_n, truth_n)
    cer = dist / max(1, len(truth_n))
    return max(0.0, min(1.0, 1.0 - cer))


def calc_percentile(data: List[int], p: float) -> float:
    if not data:
        return 0.0
    data_sorted = sorted(data)
    k = (len(data_sorted) - 1) * p
    f = int(k)
    c = min(f + 1, len(data_sorted) - 1)
    if f == c:
        return float(data_sorted[f])
    return data_sorted[f] + (data_sorted[c] - data_sorted[f]) * (k - f)


def huoshan_recognize(file_path: str) -> Tuple[str, int, dict]:
    # 与 huoshan_quik.py 对齐（本地优先）
    recognize_url = "https://openspeech.bytedance.com/api/v3/auc/bigmodel/recognize/flash"
    appid = "5851744862"
    token = "HdMaaKvnrzQ4vuLGJ0tP2u_v5Xd97_Ho"

    headers = {
        "X-Api-App-Key": appid,
        "X-Api-Access-Key": token,
        "X-Api-Resource-Id": "volc.bigasr.auc_turbo",
        "X-Api-Request-Id": str(uuid.uuid4()),
        "X-Api-Sequence": "-1",
    }

    base64_data = file_to_base64(file_path)
    audio = {
        "format": "wav",
        "codec": "raw",
        "rate": 16000,
        "bits": 16,
        "channel": 1,
        "data": base64_data,
    }
    req = {
        "user": {"uid": appid},
        "audio": audio,
        "request": {"model_name": "bigmodel"},
    }

    start_ts = time.perf_counter()
    resp = requests.post(recognize_url, json=req, headers=headers)
    elapsed_ms = int((time.perf_counter() - start_ts) * 1000)
    try:
        payload = resp.json()
    except Exception:
        payload = {"error": resp.text}

    # 提取文本（按 flash 返回结构预期）
    text = ""
    try:
        # 常见：{"result": {"text": "..."}}
        if isinstance(payload, dict):
            if "result" in payload and isinstance(payload["result"], dict):
                if isinstance(payload["result"].get("text"), str):
                    text = payload["result"]["text"].strip()
            # 兜底一些可能的字段
            if not text and isinstance(payload.get("text"), str):
                text = payload.get("text", "").strip()
    except Exception:
        pass

    return text, elapsed_ms, payload


async def main():
    import argparse

    parser = argparse.ArgumentParser(description="Batch evaluate Huoshan recognition vs labels")
    parser.add_argument("--seg-duration", type=int, default=200, help="保持与另一个脚本一致的参数占位，无实际影响")
    args = parser.parse_args()

    results: List[Tuple[str, str, str, int, float]] = []  # (file, asr, gt, ms, acc)
    latencies: List[int] = []
    acc_list: List[float] = []
    total = 0

    for folder in POSSIBLE_AUDIO_FOLDERS:
        if not os.path.isdir(folder):
            continue
        labels = load_labels_from_folder(folder)
        wav_files = glob.glob(os.path.join(folder, "*.wav"))
        for wav_path in wav_files:
            base = os.path.splitext(os.path.basename(wav_path))[0]
            gt = labels.get(base, "")
            try:
                asr, ms, _ = huoshan_recognize(wav_path)
            except Exception as e:
                asr, ms = "", -1
            norm_asr = (asr or "").strip()
            norm_gt = (gt or "").strip()
            acc = char_accuracy_ignore_punct(norm_asr, norm_gt)
            results.append((base, norm_asr, norm_gt, ms, acc))
            if ms >= 0:
                latencies.append(ms)
            acc_list.append(acc)
            total += 1

    # 表格输出对齐
    def sanitize(s: str) -> str:
        return (s or "").replace("\n", " ").replace("\r", " ")

    headers = ["文件", "用时(ms)", "准确率(忽略标点)", "识别", "标注"]
    rows = []
    for base, asr, gt, ms, acc in results:
        rows.append([
            sanitize(base),
            str(ms if ms >= 0 else "-"),
            f"{acc:.2%}",
            sanitize(asr),
            sanitize(gt),
        ])

    max_col_width = [40, 10, 14, 80, 80]
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = min(max(col_widths[i], len(cell)), max_col_width[i])

    def fmt_row(row_vals: list) -> str:
        parts = []
        for i, cell in enumerate(row_vals):
            text = cell
            if len(text) > col_widths[i]:
                text = text[: max(0, col_widths[i] - 1)] + "…"
            align = ">" if headers[i] in ("用时(ms)", "准确率(忽略标点)") else "<"
            parts.append(f"{text:{align}{col_widths[i]}}")
        return "  |  ".join(parts)

    header_line = fmt_row(headers)
    sep_line = "-" * len(header_line)
    print(header_line)
    print(sep_line)
    for r in rows:
        print(fmt_row(r))

    avg_ms = int(statistics.mean(latencies)) if latencies else 0
    p50_ms = int(calc_percentile(latencies, 0.50)) if latencies else 0
    p95_ms = int(calc_percentile(latencies, 0.95)) if latencies else 0
    avg_acc = float(statistics.mean(acc_list)) if acc_list else 0.0

    print()
    print("统计汇总")
    print("-" * 20)
    print(f"平均用时(ms): {avg_ms}")
    print(f"P50 用时(ms): {p50_ms}")
    print(f"P95 用时(ms): {p95_ms}")
    print(f"总体字符级准确率(忽略标点): {avg_acc:.2%}  样本数: {total}")


if __name__ == "__main__":
    asyncio.run(main())


